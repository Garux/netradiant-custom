var class_plugin_module =
[
    [ "PluginModule", "class_plugin_module.html#ad1ee421fa837564b34db2207141a1e8a", null ],
    [ "~PluginModule", "class_plugin_module.html#a3c1621edca71481c688d0736de6afcdb", null ],
    [ "getTable", "class_plugin_module.html#a0f526c70ec0ad44dc00ccfb23d250540", null ],
    [ "QERPluginDispatch", "class_plugin_module.html#aea1fef7abe247e06d3d09b845af5ce9f", null ],
    [ "QERPluginGetCommandList", "class_plugin_module.html#aab8f2ee0d3837bfdb27732800d197c0c", null ],
    [ "QERPluginGetCommandTitleList", "class_plugin_module.html#a7d266d544ff8e01213d922291dbe7cb0", null ],
    [ "QERPluginGetName", "class_plugin_module.html#a9eac1940d4875bae5088e5f9db594be3", null ],
    [ "QERPluginInit", "class_plugin_module.html#a8ae54ffb14cac7dfc88e85b1dfc02f8a", null ],
    [ "_pluginAPI", "class_plugin_module.html#ad9ff535d83971cd03bc4f0920bb9021f", null ]
];