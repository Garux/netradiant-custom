var group__meshtex_plugin =
[
    [ "PluginProperties.h", "_plugin_properties_8h.html", null ],
    [ "PluginRegistration.cpp", "_plugin_registration_8cpp.html", null ],
    [ "MeshTexPluginDependencies", "class_mesh_tex_plugin_dependencies.html", null ]
];