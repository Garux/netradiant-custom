var struct_mesh_entity_1_1_slice_patch_context =
[
    [ "edgeSlice", "struct_mesh_entity_1_1_slice_patch_context.html#a2410cf1804efd2ce8c5812cafc524a4a", null ],
    [ "position", "struct_mesh_entity_1_1_slice_patch_context.html#a2852969348f0491964ed0263c266adf0", null ],
    [ "sliceType", "struct_mesh_entity_1_1_slice_patch_context.html#abe7838b86fd9e3266d972db9424cb8a9", null ]
];