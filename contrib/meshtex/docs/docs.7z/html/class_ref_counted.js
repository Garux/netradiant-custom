var class_ref_counted =
[
    [ "RefCounted", "class_ref_counted.html#a0f4d8212944ba431ea79c4fc55f093f8", null ],
    [ "~RefCounted", "class_ref_counted.html#ae0e479f727bc590b9dc0592054af10ff", null ],
    [ "DecRef", "class_ref_counted.html#ac6f6465499c04a4e5b4ed70c7fa20ce2", null ],
    [ "IncRef", "class_ref_counted.html#a1b256b12c50f0ed1770366de7e9e40df", null ],
    [ "_refCount", "class_ref_counted.html#a5b871bfd787d6b4f1b7bd69b37ed0aea", null ]
];