var class_plugin_u_i =
[
    [ "PluginUI", "class_plugin_u_i.html#a0611fbefaf10ba9d2d781581dab2d85a", null ],
    [ "~PluginUI", "class_plugin_u_i.html#a8ff5c8f572f9bacf8f68bc3a946de873", null ],
    [ "Instance", "class_plugin_u_i.html#a8240508ce62702e7d6eb414db40a9ac6", null ]
];