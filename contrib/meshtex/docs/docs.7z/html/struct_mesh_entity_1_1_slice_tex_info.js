var struct_mesh_entity_1_1_slice_tex_info =
[
    [ "max", "struct_mesh_entity_1_1_slice_tex_info.html#ad62d7673876ac5fc1660bc75ae1fec73", null ],
    [ "min", "struct_mesh_entity_1_1_slice_tex_info.html#a8daa8f270e5d88c84a0bb20fc3e84647", null ],
    [ "scale", "struct_mesh_entity_1_1_slice_tex_info.html#a35d982fdd7d1c30a114ae9051669c9ca", null ],
    [ "tiles", "struct_mesh_entity_1_1_slice_tex_info.html#ade658ea03c59f4a0b7b46fe00b16a730", null ]
];