var class_allocated_matrix =
[
    [ "AllocatedMatrix", "class_allocated_matrix.html#abfe294329c6d79f5562f1b16c8eb8b5c", null ],
    [ "~AllocatedMatrix", "class_allocated_matrix.html#a8bf9ae7d6e1916843687bdc0802ac8d0", null ],
    [ "_allocated", "class_allocated_matrix.html#adaf613355486a0d79031e2865039077c", null ]
];