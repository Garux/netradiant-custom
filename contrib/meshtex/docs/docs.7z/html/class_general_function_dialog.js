var class_general_function_dialog =
[
    [ "GeneralFunctionVisitor", "class_general_function_dialog_1_1_general_function_visitor.html", "class_general_function_dialog_1_1_general_function_visitor" ],
    [ "GeneralFunctionDialog", "class_general_function_dialog.html#a223db45ec2e778514f02c6b38a4be1f9", null ],
    [ "~GeneralFunctionDialog", "class_general_function_dialog.html#aebf463ca4eed20ff6af5312d99a7600b", null ],
    [ "Apply", "class_general_function_dialog.html#a5dba8293ef1b3ef5ad1796b3efe1912a", null ],
    [ "_nullVisitor", "class_general_function_dialog.html#af160da50d2e10910365d1dc5e6e0574d", null ]
];