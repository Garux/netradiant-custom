var _generic_plugin_u_i_messages_8h =
[
    [ "DIALOG_APPLY_BUTTON", "_generic_plugin_u_i_messages_8h.html#a2253e76015e72752b66b65489a36ba70", null ],
    [ "DIALOG_CANCEL_BUTTON", "_generic_plugin_u_i_messages_8h.html#ac0f5021c756b95adae52e4d2630a8eed", null ],
    [ "DIALOG_ERROR_TITLE", "_generic_plugin_u_i_messages_8h.html#abb7e3b79e776e5e15a4c96e4bc732808", null ],
    [ "DIALOG_INTERNAL_ERROR", "_generic_plugin_u_i_messages_8h.html#aebc0cf5307f6d07bf025a881a42a9ceb", null ],
    [ "DIALOG_OK_BUTTON", "_generic_plugin_u_i_messages_8h.html#a94350789355524be9569b0976f71395a", null ],
    [ "DIALOG_WARNING_TITLE", "_generic_plugin_u_i_messages_8h.html#a649efb637142d4ef1fdb4e4326bcb2f5", null ]
];