var group__meshtex_ui =
[
    [ "GeneralFunctionDialog.cpp", "_general_function_dialog_8cpp.html", null ],
    [ "GeneralFunctionDialog.h", "_general_function_dialog_8h.html", null ],
    [ "GetInfoDialog.cpp", "_get_info_dialog_8cpp.html", null ],
    [ "GetInfoDialog.h", "_get_info_dialog_8h.html", null ],
    [ "MainMenu.cpp", "_main_menu_8cpp.html", null ],
    [ "MainMenu.h", "_main_menu_8h.html", null ],
    [ "PluginUI.cpp", "_plugin_u_i_8cpp.html", null ],
    [ "PluginUI.h", "_plugin_u_i_8h.html", null ],
    [ "PluginUIMessages.h", "_plugin_u_i_messages_8h.html", null ],
    [ "SetScaleDialog.cpp", "_set_scale_dialog_8cpp.html", null ],
    [ "SetScaleDialog.h", "_set_scale_dialog_8h.html", null ],
    [ "GeneralFunctionDialog", "class_general_function_dialog.html", null ],
    [ "GetInfoDialog", "class_get_info_dialog.html", null ],
    [ "MainMenu", "class_main_menu.html", null ],
    [ "PluginUI", "class_plugin_u_i.html", null ],
    [ "SetScaleDialog", "class_set_scale_dialog.html", null ]
];