var searchData=
[
  ['namedentrywidgettext',['NamedEntryWidgetText',['../_generic_dialog_8h.html#a03a264202114bf353cc170b709d86401',1,'GenericDialog.h']]],
  ['namedtogglewidgetactive',['NamedToggleWidgetActive',['../_generic_dialog_8h.html#a2e52c6e69fdd34ac79ff058bc165fcea',1,'GenericDialog.h']]],
  ['namedwidget',['NamedWidget',['../_generic_dialog_8h.html#aed92ceab026bc6138d47eefab12b4b40',1,'GenericDialog.h']]]
];
