var searchData=
[
  ['designation',['designation',['../struct_mesh_entity_1_1_ref_slice_descriptor.html#a3fbf6a00ae8338a61a237918a6ed4931',1,'MeshEntity::RefSliceDescriptor']]]
];
