var searchData=
[
  ['textureaxis',['TextureAxis',['../class_mesh_entity.html#a770df881e27ba52fa9382b055fed91d4',1,'MeshEntity']]],
  ['textureaxisselection',['TextureAxisSelection',['../class_mesh_entity.html#a8a1e03cfd001377dc03892eeb00d417d',1,'MeshEntity']]]
];
