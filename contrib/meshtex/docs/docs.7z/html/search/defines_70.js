var searchData=
[
  ['plugin_5fname',['PLUGIN_NAME',['../_plugin_properties_8h.html#a0acf7475326cdcd31d690b72033de33a',1,'PluginProperties.h']]]
];
