var searchData=
[
  ['generic',['Generic',['../group__generic.html',1,'']]],
  ['generic_20plugin',['Generic Plugin',['../group__generic-plugin.html',1,'']]],
  ['generic_20ui',['Generic UI',['../group__generic-ui.html',1,'']]],
  ['generic_20util',['Generic Util',['../group__generic-util.html',1,'']]]
];
