var searchData=
[
  ['dialogeventcallbackmethod',['DialogEventCallbackMethod',['../class_generic_plugin_u_i_1_1_dialog_event_callback_method.html',1,'GenericPluginUI']]],
  ['dialogsignalcallbackmethod',['DialogSignalCallbackMethod',['../class_generic_plugin_u_i_1_1_dialog_signal_callback_method.html',1,'GenericPluginUI']]],
  ['dialogsignalcallbackmethod_3c_20genericpluginui_2c_26genericpluginui_3a_3awidgetcontrolcallback_20_3e',['DialogSignalCallbackMethod&lt; GenericPluginUI,&amp;GenericPluginUI::WidgetControlCallback &gt;',['../class_generic_plugin_u_i_1_1_dialog_signal_callback_method.html',1,'GenericPluginUI']]]
];
