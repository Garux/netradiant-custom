var searchData=
[
  ['finalizecallback',['FinalizeCallback',['../class_generic_dialog.html#a7b8b07212d330f9440ae3d683b0669fd',1,'GenericDialog']]]
];
