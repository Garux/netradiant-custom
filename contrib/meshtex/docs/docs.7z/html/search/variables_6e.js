var searchData=
[
  ['naturalscale',['naturalScale',['../struct_set_scale_dialog_1_1_set_scale_visitor_1_1_slice_args.html#ae3250acea9c007c594ca41b37caa632e',1,'SetScaleDialog::SetScaleVisitor::SliceArgs']]]
];
