var searchData=
[
  ['t_5ftex_5faxis',['T_TEX_AXIS',['../class_mesh_entity.html#a770df881e27ba52fa9382b055fed91d4ac216430e3ab65a92779820ddf6ce78a3',1,'MeshEntity']]],
  ['t_5ftex_5faxis_5fonly',['T_TEX_AXIS_ONLY',['../class_mesh_entity.html#a8a1e03cfd001377dc03892eeb00d417da034ec25f41e2d797cced769f1e95acd1',1,'MeshEntity']]]
];
