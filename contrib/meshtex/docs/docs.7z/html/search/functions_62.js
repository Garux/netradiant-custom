var searchData=
[
  ['beginentries',['BeginEntries',['../class_generic_main_menu.html#a2bce5d8b7dfd41f277c158ab8461d1bb',1,'GenericMainMenu']]]
];
