var searchData=
[
  ['warningreportdialog',['WarningReportDialog',['../class_generic_plugin_u_i.html#af31c51527dc043e22ab6040ede73d06e',1,'GenericPluginUI']]],
  ['widgetcontrolcallback',['WidgetControlCallback',['../class_generic_plugin_u_i.html#a892c1cfdf28a590267a3104a85a4ece6',1,'GenericPluginUI']]]
];
