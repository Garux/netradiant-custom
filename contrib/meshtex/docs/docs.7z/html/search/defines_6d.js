var searchData=
[
  ['menu_5fseparator',['MENU_SEPARATOR',['../_generic_main_menu_8h.html#abb984eebe8255da82b79ec0944753600',1,'GenericMainMenu.h']]]
];
