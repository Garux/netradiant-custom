var searchData=
[
  ['alignslice',['alignSlice',['../struct_set_scale_dialog_1_1_set_scale_visitor_1_1_slice_args.html#a6bf31d044c4864f49c14748ae9c492da',1,'SetScaleDialog::SetScaleVisitor::SliceArgs']]]
];
