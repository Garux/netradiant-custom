var searchData=
[
  ['widgetdependencemap',['WidgetDependenceMap',['../class_generic_plugin_u_i.html#a1829b27ecc37ca98eadfb2ed55096d29',1,'GenericPluginUI']]]
];
