var searchData=
[
  ['allocatedmatrix',['AllocatedMatrix',['../class_allocated_matrix.html',1,'']]]
];
