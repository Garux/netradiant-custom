var group__generic_plugin =
[
    [ "PluginModule.cpp", "_plugin_module_8cpp.html", null ],
    [ "PluginModule.h", "_plugin_module_8h.html", null ],
    [ "PluginModule", "class_plugin_module.html", null ]
];