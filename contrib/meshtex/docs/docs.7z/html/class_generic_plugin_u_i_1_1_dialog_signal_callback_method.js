var class_generic_plugin_u_i_1_1_dialog_signal_callback_method =
[
    [ "DialogSignalCallbackMethod", "class_generic_plugin_u_i_1_1_dialog_signal_callback_method.html#af4f2bc4cde0832d61079e430b1005b6b", null ]
];