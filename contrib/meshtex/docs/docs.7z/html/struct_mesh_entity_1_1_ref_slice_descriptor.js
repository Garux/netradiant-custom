var struct_mesh_entity_1_1_ref_slice_descriptor =
[
    [ "designation", "struct_mesh_entity_1_1_ref_slice_descriptor.html#a3fbf6a00ae8338a61a237918a6ed4931", null ],
    [ "totalLengthOnly", "struct_mesh_entity_1_1_ref_slice_descriptor.html#acbd6d79f8bd17c92bc56b9f07ab3e020", null ]
];