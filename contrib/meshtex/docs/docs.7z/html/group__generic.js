var group__generic =
[
    [ "Generic Plugin", "group__generic-plugin.html", "group__generic-plugin" ],
    [ "Generic UI", "group__generic-ui.html", "group__generic-ui" ],
    [ "Generic Util", "group__generic-util.html", "group__generic-util" ]
];