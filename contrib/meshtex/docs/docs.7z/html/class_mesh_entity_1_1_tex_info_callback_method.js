var class_mesh_entity_1_1_tex_info_callback_method =
[
    [ "TexInfoCallbackMethod", "class_mesh_entity_1_1_tex_info_callback_method.html#a9fd2cb698b7172329205e536b451008a", null ]
];