var _plugin_properties_8h =
[
    [ "PLUGIN_AUTHOR", "_plugin_properties_8h.html#a265068a76dad4b9410dc4f7fad66ebd6", null ],
    [ "PLUGIN_AUTHOR_EMAIL", "_plugin_properties_8h.html#afad57e8cc5c25caeb109c8cf4f6ab1b8", null ],
    [ "PLUGIN_COPYRIGHT_DATE", "_plugin_properties_8h.html#ac6f5bf49f8b3beb77d719ceb2c33964c", null ],
    [ "PLUGIN_DESCRIPTION", "_plugin_properties_8h.html#a02783773d3c73e1e9f63c1181d39e93a", null ],
    [ "PLUGIN_FILE_BASENAME", "_plugin_properties_8h.html#ad4a05719a621e7c5393683e71fd66cc0", null ],
    [ "PLUGIN_FILE_DESCRIPTION", "_plugin_properties_8h.html#aa043ca3bab73837a726afe9ff18e320c", null ],
    [ "PLUGIN_NAME", "_plugin_properties_8h.html#a0acf7475326cdcd31d690b72033de33a", null ],
    [ "PLUGIN_VERSION", "_plugin_properties_8h.html#afccad64028fb6c9ac2923be268a89efb", null ],
    [ "PLUGIN_VERSION_MAJOR_NUMERIC", "_plugin_properties_8h.html#a8d230fbed193712c76947c67a1659627", null ],
    [ "PLUGIN_VERSION_MINOR_NUMERIC", "_plugin_properties_8h.html#a74d917cb4b06f6f4403d87ad9557b8ca", null ]
];