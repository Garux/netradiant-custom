var class_set_scale_dialog_1_1_set_scale_visitor =
[
    [ "SliceArgs", "struct_set_scale_dialog_1_1_set_scale_visitor_1_1_slice_args.html", "struct_set_scale_dialog_1_1_set_scale_visitor_1_1_slice_args" ],
    [ "SetScaleVisitor", "class_set_scale_dialog_1_1_set_scale_visitor.html#a3c744f936180845d8bb01a1a801aea40", null ],
    [ "Execute", "class_set_scale_dialog_1_1_set_scale_visitor.html#a86baf6170f93c393f209f7b6077d9365", null ],
    [ "_colArgs", "class_set_scale_dialog_1_1_set_scale_visitor.html#a2b63535c050bd334d187ae4c1069c3c6", null ],
    [ "_rowArgs", "class_set_scale_dialog_1_1_set_scale_visitor.html#a384a78b287455fef14423787202e3b0f", null ]
];