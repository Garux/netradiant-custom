var class_generic_plugin_u_i_1_1_dialog_event_callback_method =
[
    [ "DialogEventCallbackMethod", "class_generic_plugin_u_i_1_1_dialog_event_callback_method.html#ac8b4cc46220481635fa34c4b3dd2c559", null ]
];