var struct_mesh_entity_1_1_ref_slice_descriptor_int =
[
    [ "index", "struct_mesh_entity_1_1_ref_slice_descriptor_int.html#a37c92c8e9f92b054f26f65938ab02c44", null ],
    [ "totalLengthOnly", "struct_mesh_entity_1_1_ref_slice_descriptor_int.html#ada154e06ae440dff2535292cf68aa026", null ]
];