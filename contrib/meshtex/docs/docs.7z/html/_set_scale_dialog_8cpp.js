var _set_scale_dialog_8cpp =
[
    [ "ENTRY_BUFFER_SIZE", "_set_scale_dialog_8cpp.html#a71ed4c744b18e1f5f858d6a75aa340d7", null ]
];