var group__generic_ui =
[
    [ "GenericDialog.cpp", "_generic_dialog_8cpp.html", null ],
    [ "GenericDialog.h", "_generic_dialog_8h.html", null ],
    [ "GenericMainMenu.cpp", "_generic_main_menu_8cpp.html", null ],
    [ "GenericMainMenu.h", "_generic_main_menu_8h.html", null ],
    [ "GenericPluginUI.cpp", "_generic_plugin_u_i_8cpp.html", null ],
    [ "GenericPluginUI.h", "_generic_plugin_u_i_8h.html", null ],
    [ "GenericPluginUIMessages.h", "_generic_plugin_u_i_messages_8h.html", null ],
    [ "GenericDialog", "class_generic_dialog.html", null ],
    [ "GenericMainMenu", "class_generic_main_menu.html", null ],
    [ "GenericPluginUI", "class_generic_plugin_u_i.html", null ]
];