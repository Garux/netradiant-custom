var struct_set_scale_dialog_1_1_set_scale_visitor_1_1_slice_args =
[
    [ "alignSlice", "struct_set_scale_dialog_1_1_set_scale_visitor_1_1_slice_args.html#a6bf31d044c4864f49c14748ae9c492da", null ],
    [ "naturalScale", "struct_set_scale_dialog_1_1_set_scale_visitor_1_1_slice_args.html#ae3250acea9c007c594ca41b37caa632e", null ],
    [ "refSlice", "struct_set_scale_dialog_1_1_set_scale_visitor_1_1_slice_args.html#a96cffa058a295a3209bb1d6432eb4363", null ],
    [ "scaleOrTiles", "struct_set_scale_dialog_1_1_set_scale_visitor_1_1_slice_args.html#a85736fcbea54b689c28b38677eaedaed", null ]
];