var class_mesh_tex_plugin_dependencies =
[
    [ "MeshTexPluginDependencies", "class_mesh_tex_plugin_dependencies.html#ad08147d01193fc8e7400af2970a4046d", null ],
    [ "Radiant_RegisterModules", "class_mesh_tex_plugin_dependencies.html#a91877911c6759eec3d036970ec5d59b5", null ]
];