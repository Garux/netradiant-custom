var struct_mesh_entity_1_1_slice_designation =
[
    [ "index", "struct_mesh_entity_1_1_slice_designation.html#a3797c64176f1d7ef17ed20ae504ab39c", null ],
    [ "maxSlice", "struct_mesh_entity_1_1_slice_designation.html#a2797cfe7e10cb9a35c7f98c9280991a4", null ]
];